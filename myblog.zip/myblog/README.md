# The Daily Post — Django Blog

A simple blog application built with Django.

## Features
- List all posts
- Create new posts
- Edit existing posts
- Delete posts

## Setup & Run

```bash
# Install Django
pip install django

# Apply migrations
python manage.py migrate

# Start the server
python manage.py runserver
```

Then open: http://127.0.0.1:8000/

## Project Structure
```
myblog/
├── blog/
│   ├── models.py      # Post model
│   ├── views.py       # CRUD views
│   ├── urls.py        # URL routes
│   ├── forms.py       # Post form
│   └── templates/blog/
│       ├── base.html
│       ├── post_list.html
│       ├── post_detail.html
│       ├── post_form.html
│       └── post_confirm_delete.html
└── myblog/
    ├── settings.py
    └── urls.py
```
